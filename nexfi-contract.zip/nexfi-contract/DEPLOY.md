# 🚀 NEXFI Contract — Deploy Guide

## Langkah Deploy ke OP_NET Testnet

### 1. Install Prerequisites

```bash
# Node.js 18+ diperlukan
node -v

# Install OP_NET CLI global
npm install -g @btc-vision/opnet-cli

# Install dependencies
npm install
```

---

### 2. Siapkan Wallet & Testnet BTC

Kamu butuh:
- **OP Wallet** extension: https://chromewebstore.google.com/detail/opwallet/pmbjpcmaaladnfpacpmhmnfmpklgbdjb
- **Testnet BTC** untuk gas (klaim gratis di faucet):
  - https://testnet-faucet.mempool.co
  - https://bitcoinfaucet.uo1.net

Ekspor **WIF (Wallet Import Format)** private key dari OP Wallet:
`OP Wallet → Settings → Export Private Key → Copy WIF`

---

### 3. Set Environment Variable

```bash
# Mac / Linux
export DEPLOYER_WIF="cYourPrivateKeyWIFHere..."

# Windows PowerShell
$env:DEPLOYER_WIF="cYourPrivateKeyWIFHere..."
```

> ⚠️ Jangan pernah commit private key ke Git!

---

### 4. Build Contract

```bash
npm run build
```

Output: `dist/NexfiLending.wasm` + `dist/NexfiLending.abi.json`

---

### 5. Deploy ke Testnet

```bash
npm run deploy:test
```

Output yang diharapkan:
```
✅ Contract deployed!
📋 Address: opt1sq...xxxx
🔍 OPScan:  https://opscan.org/accounts/opt1sq...?network=op_testnet
```

---

### 6. Update NEXFI_CONTRACT di HTML

Buka `nexfi-defi-fixed.html`, cari baris:
```javascript
const NEXFI_CONTRACT = 'opt1sqrrqhhyn6zh9t32tpxlhr5rp7qqe7ga7sq8secql';
```

Ganti dengan contract address yang baru dari hasil deploy.

---

### 7. Deploy Token Contracts (OP-20)

Untuk setiap token (WBTC, USDT, USDC, MOTO, OPILL), deploy OP-20 contract
terpisah atau gunakan existing token addresses dari OP_NET Testnet:

```
# Cek token yang sudah ada di:
https://opscan.org/?network=op_testnet
```

Lalu update `TOKEN_CONTRACTS` di HTML dengan address yang benar.

---

## Contract Functions & Selectors

| Function | Selector | Parameters |
|---|---|---|
| `supply` | `0x6f0f8f65` | `(address token, uint256 amount)` |
| `withdraw` | `0x2e1a7d4d` | `(address token, uint256 amount)` |
| `borrow` | `0xd0e30db0` | `(address token, uint256 amount)` |
| `repay` | `0x22867d78` | `(address token, uint256 amount)` |
| `getSupplyBalance` | view | `(address user, address token)` |
| `getBorrowBalance` | view | `(address user, address token)` |

---

## Troubleshooting

**"insufficient gas"** → Klaim lebih banyak testnet BTC dari faucet

**"transferFrom failed"** → Frontend perlu panggil `approve()` dulu sebelum supply/repay
(sudah dihandle otomatis di `nexfi-defi-fixed.html`)

**"contract not found"** → Pastikan deploy berhasil dan address di HTML sudah diupdate

---

## Resources

- OP_NET Docs: https://docs.opnet.org
- OPScan Testnet: https://opscan.org/?network=op_testnet
- OP_NET GitHub: https://github.com/btc-vision
- Discord: https://discord.gg/opnet
