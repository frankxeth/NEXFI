import {
  Address,
  Blockchain,
  BytesWriter,
  Calldata,
  encodePointer,
  MemorySlotData,
  MemorySlotPointer,
  SafeMath,
  StoredU256,
  StoredString,
  u256,
} from '@btc-vision/btc-runtime/runtime';
import { OP_20 } from 'opnet';

/**
 * NEXFI Lending Protocol — OP_NET Bitcoin L1
 * -------------------------------------------------
 * Fungsi utama:
 *   supply(token, amount)   — deposit token sebagai collateral / earning yield
 *   withdraw(token, amount) — tarik deposit
 *   borrow(token, amount)   — pinjam token dengan jaminan collateral
 *   repay(token, amount)    — bayar kembali pinjaman
 *
 * Deploy: opnet deploy --network testnet
 */

@final
export class NexfiLending extends OP_20 {

  // ── Storage pointers ──────────────────────────────────────────
  private readonly SUPPLY_POINTER:    u16 = 200;
  private readonly BORROW_POINTER:    u16 = 201;
  private readonly TOTAL_SUPPLY_PTR:  u16 = 202;
  private readonly TOTAL_BORROW_PTR:  u16 = 203;
  private readonly HEALTH_FACTOR_PTR: u16 = 204;
  private readonly PAUSED_PTR:        u16 = 205;

  // Liquidation threshold: Health Factor < 1.0 = liquidatable
  private readonly LIQUIDATION_THRESHOLD: u256 = u256.fromU32(100); // 100 = 1.0 scaled x100
  private readonly COLLATERAL_FACTOR:     u256 = u256.fromU32(75);  // 75%
  private readonly LIQUIDATION_BONUS:     u256 = u256.fromU32(5);   // 5%

  constructor() {
    super(
      u256.fromU32(0),       // initial supply (minted dynamically as nTokens)
      18,                    // decimals
      'NEXFI LP Token',
      'nNEXFI'
    );
  }

  // ── Public entry points ───────────────────────────────────────

  /**
   * supply(address token, uint256 amount)
   * Selector: 0x6f0f8f65
   *
   * User deposits `amount` of `token` into the NEXFI pool.
   * In return they receive nTokens representing their share.
   */
  public supply(calldata: Calldata): BytesWriter {
    const token:  Address = calldata.readAddress();
    const amount: u256    = calldata.readU256();

    this._requireNotPaused();
    this._requireNonZero(amount);

    const caller = Blockchain.tx.sender;

    // Transfer tokens from caller to this contract
    const tokenContract = this._getToken(token);
    const ok = tokenContract.transferFrom(caller, Blockchain.contractAddress, amount);
    if (!ok) throw new Error('NEXFI: transferFrom failed — check approval');

    // Update supply balance
    const key = encodePointer(this.SUPPLY_POINTER, caller, token);
    const prev = this._loadU256(key);
    this._storeU256(key, SafeMath.add(prev, amount));

    // Update total supply
    const totalKey = encodePointer(this.TOTAL_SUPPLY_PTR, token);
    const prevTotal = this._loadU256(totalKey);
    this._storeU256(totalKey, SafeMath.add(prevTotal, amount));

    // Emit event
    const result = new BytesWriter(64);
    result.writeStringWithLength('Supply');
    result.writeAddress(caller);
    result.writeAddress(token);
    result.writeU256(amount);
    return result;
  }

  /**
   * withdraw(address token, uint256 amount)
   * Selector: 0x2e1a7d4d
   *
   * User withdraws previously supplied tokens.
   */
  public withdraw(calldata: Calldata): BytesWriter {
    const token:  Address = calldata.readAddress();
    const amount: u256    = calldata.readU256();

    this._requireNotPaused();
    this._requireNonZero(amount);

    const caller = Blockchain.tx.sender;
    const key    = encodePointer(this.SUPPLY_POINTER, caller, token);
    const balance = this._loadU256(key);

    if (u256.lt(balance, amount)) throw new Error('NEXFI: insufficient supply balance');

    // Check health factor after withdrawal
    this._requireHealthyAfterWithdraw(caller, token, amount);

    this._storeU256(key, SafeMath.sub(balance, amount));

    const totalKey = encodePointer(this.TOTAL_SUPPLY_PTR, token);
    const prevTotal = this._loadU256(totalKey);
    this._storeU256(totalKey, SafeMath.sub(prevTotal, amount));

    // Transfer tokens back to caller
    const tokenContract = this._getToken(token);
    const ok = tokenContract.transfer(caller, amount);
    if (!ok) throw new Error('NEXFI: transfer failed');

    const result = new BytesWriter(64);
    result.writeStringWithLength('Withdraw');
    result.writeAddress(caller);
    result.writeAddress(token);
    result.writeU256(amount);
    return result;
  }

  /**
   * borrow(address token, uint256 amount)
   * Selector: 0xd0e30db0
   *
   * User borrows `amount` of `token` against their collateral.
   * Requires sufficient collateral (150% min collateral ratio).
   */
  public borrow(calldata: Calldata): BytesWriter {
    const token:  Address = calldata.readAddress();
    const amount: u256    = calldata.readU256();

    this._requireNotPaused();
    this._requireNonZero(amount);

    const caller = Blockchain.tx.sender;

    // Verify borrow limit
    this._requireBorrowAllowed(caller, token, amount);

    // Update borrow balance
    const borrowKey = encodePointer(this.BORROW_POINTER, caller, token);
    const prev = this._loadU256(borrowKey);
    this._storeU256(borrowKey, SafeMath.add(prev, amount));

    const totalKey = encodePointer(this.TOTAL_BORROW_PTR, token);
    const prevTotal = this._loadU256(totalKey);
    this._storeU256(totalKey, SafeMath.add(prevTotal, amount));

    // Transfer borrowed tokens to caller
    const tokenContract = this._getToken(token);
    const ok = tokenContract.transfer(caller, amount);
    if (!ok) throw new Error('NEXFI: insufficient liquidity in pool');

    const result = new BytesWriter(64);
    result.writeStringWithLength('Borrow');
    result.writeAddress(caller);
    result.writeAddress(token);
    result.writeU256(amount);
    return result;
  }

  /**
   * repay(address token, uint256 amount)
   * Selector: 0x22867d78
   *
   * User repays `amount` of borrowed `token`.
   */
  public repay(calldata: Calldata): BytesWriter {
    const token:  Address = calldata.readAddress();
    const amount: u256    = calldata.readU256();

    this._requireNonZero(amount);

    const caller = Blockchain.tx.sender;
    const borrowKey = encodePointer(this.BORROW_POINTER, caller, token);
    const debt = this._loadU256(borrowKey);

    if (u256.lt(debt, amount)) throw new Error('NEXFI: repay amount exceeds debt');

    // Transfer repayment from caller
    const tokenContract = this._getToken(token);
    const ok = tokenContract.transferFrom(caller, Blockchain.contractAddress, amount);
    if (!ok) throw new Error('NEXFI: repay transferFrom failed');

    this._storeU256(borrowKey, SafeMath.sub(debt, amount));

    const totalKey = encodePointer(this.TOTAL_BORROW_PTR, token);
    const prevTotal = this._loadU256(totalKey);
    this._storeU256(totalKey, SafeMath.sub(prevTotal, amount));

    const result = new BytesWriter(64);
    result.writeStringWithLength('Repay');
    result.writeAddress(caller);
    result.writeAddress(token);
    result.writeU256(amount);
    return result;
  }

  /**
   * getSupplyBalance(address user, address token) → uint256
   * View function — returns supply balance of user for a token
   */
  public getSupplyBalance(calldata: Calldata): BytesWriter {
    const user:  Address = calldata.readAddress();
    const token: Address = calldata.readAddress();
    const key = encodePointer(this.SUPPLY_POINTER, user, token);
    const bal = this._loadU256(key);
    const result = new BytesWriter(32);
    result.writeU256(bal);
    return result;
  }

  /**
   * getBorrowBalance(address user, address token) → uint256
   */
  public getBorrowBalance(calldata: Calldata): BytesWriter {
    const user:  Address = calldata.readAddress();
    const token: Address = calldata.readAddress();
    const key = encodePointer(this.BORROW_POINTER, user, token);
    const bal = this._loadU256(key);
    const result = new BytesWriter(32);
    result.writeU256(bal);
    return result;
  }

  // ── Internal helpers ──────────────────────────────────────────

  private _getToken(addr: Address): OP_20 {
    return new OP_20(addr);
  }

  private _loadU256(pointer: MemorySlotPointer): u256 {
    const slot = Blockchain.getStorageAt(pointer, u256.Zero);
    return slot;
  }

  private _storeU256(pointer: MemorySlotPointer, value: u256): void {
    Blockchain.setStorageAt(pointer, value);
  }

  private _requireNonZero(amount: u256): void {
    if (u256.eq(amount, u256.Zero)) throw new Error('NEXFI: amount must be > 0');
  }

  private _requireNotPaused(): void {
    const key = encodePointer(this.PAUSED_PTR);
    const paused = this._loadU256(key);
    if (!u256.eq(paused, u256.Zero)) throw new Error('NEXFI: protocol is paused');
  }

  private _requireBorrowAllowed(caller: Address, token: Address, amount: u256): void {
    // Simplified check: total supply value * 75% >= total borrow + new borrow
    const supplyKey = encodePointer(this.SUPPLY_POINTER, caller, token);
    const supply = this._loadU256(supplyKey);
    // collateralValue = supply * 75 / 100
    const collateral = SafeMath.div(SafeMath.mul(supply, this.COLLATERAL_FACTOR), u256.fromU32(100));
    const borrowKey  = encodePointer(this.BORROW_POINTER, caller, token);
    const existing   = this._loadU256(borrowKey);
    const newTotal   = SafeMath.add(existing, amount);
    if (u256.lt(collateral, newTotal)) throw new Error('NEXFI: insufficient collateral');
  }

  private _requireHealthyAfterWithdraw(caller: Address, token: Address, amount: u256): void {
    const supplyKey = encodePointer(this.SUPPLY_POINTER, caller, token);
    const supply    = this._loadU256(supplyKey);
    const newSupply = SafeMath.sub(supply, amount);
    const borrowKey = encodePointer(this.BORROW_POINTER, caller, token);
    const debt      = this._loadU256(borrowKey);
    if (u256.eq(debt, u256.Zero)) return; // no debt, always healthy
    // health = newSupply * 75 / (debt * 100)
    const collateral = SafeMath.mul(newSupply, this.COLLATERAL_FACTOR);
    const debtScaled = SafeMath.mul(debt, u256.fromU32(100));
    if (u256.lt(collateral, debtScaled)) throw new Error('NEXFI: withdrawal would cause undercollateralization');
  }
}
